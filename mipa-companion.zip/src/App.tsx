import React from "react";
import AccommodationApp from "./components/AccommodationApp";
import "./styles.css";

function App() {
  return <AccommodationApp />;
}

export default App;
